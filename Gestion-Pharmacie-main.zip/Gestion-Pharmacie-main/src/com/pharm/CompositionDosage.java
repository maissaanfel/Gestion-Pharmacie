package com.pharm;

public class CompositionDosage {
    private String composition;
    private float dosage;

    public CompositionDosage(String composition, float dosage) {
        this.composition = composition;
        this.dosage = dosage;
    }
}
